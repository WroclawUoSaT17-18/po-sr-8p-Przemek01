package com.example.ery00.plan_zajec_klient;

/**
 * Created by ery00 on 2018-04-18.
 */

public class ListaPobierz {


    public String nazwa;
    public String pobierz;



    public ListaPobierz(
            String nazwa,
            String pobierz
            ){

        this.nazwa = nazwa;
        this.pobierz = pobierz;
    }
}
